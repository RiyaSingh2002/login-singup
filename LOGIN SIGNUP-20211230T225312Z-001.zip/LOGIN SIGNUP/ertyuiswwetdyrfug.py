import json
import requests
res=requests.get("http://saral.navgurukul.org/api/courses")
data1=res.json()
print(data1)
data1 =(text["availableCourses"])
def course():
    index=0
    for i in data1:
        print(index+1,i["name"],i["id"])
        index=index+1
    for c in data1["availablecourses"]:
        course=int(input("selectyour courses"))
        select=data1["availabecourse"][course-1]["id"]
        var=requests.get("http://saral.navgurukul.org/api/courses"+str(select)+"/exercise")
        data2=var.json()
        print(data2)
    
course()