import json
import requests
res=requests.get("http://saral.navgurukul.org/api/courses")
data_text=res.json()
# print(data_text)
# data1 =(data_text["availableCourses"])
with open("sai.json","w")as file:
    a=json.dump(data_text,file,indent=4)
# b=json.dumps(a)
# print(type(b))
def course():
    index=1
    for i in data_text["availableCourses"]:
        print(index,i["name"],i["id"])
        index=index+1
    for c in data_text["availableCourses"]:
        course=int(input("selectyour courses"))
        select=data_text["availableCourses"][course-1]["id"]
        var=requests.get("http://saral.navgurukul.org/api/courses/"+str(select)+"/exercises/get")
        for c in data_text["availableCourses"]:
        course=int(input("selectyour courses"))
        select=data_text["availableCourses"][course-1]["id"]
        var=requests.get("http://saral.navgurukul.org/api/courses/"+str(select)+"/exercises")
        data2=var.json()
        print(data2)
        data2=var.json()
        print(data2)
    # for j in data_text["availableCourses"]:
   
    #     for courses in data_text["availableCourses"]:
    #         course=int(input("selectyour courses"))
    #         select=data_text["availableCourses"][course-1]["id"]
    #         var=requests.get("http://saral.navgurukul.org/api/courses"+str(select)+"/exercise/get")
    #         data2=var.json()
    #         print(data2)
    #     slug=[]
    #     count3=1
    # for dic_data2 in data2["data"]:
    #                 print(count3,dic_data2["name"])
    #                 slug.append(dic_data2["slug"])
    #                 count3=count3+1


course()