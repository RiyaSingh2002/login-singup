r=1
while r<=4:
	j=1
	while j<=5:
		if r==1 and (j==1 or j==5):
			print("*",end=" ")
			j+=1
		elif r==2 and (j==1 or j==3 or j==5):
			print("*",end=" ")
			j+=1
		elif r==3 and (j==1 or j==2 or j==4 or j==5):
			print("*",end=" ")
			j+=1
		elif r==4 and (j==1 or j==5):
			print("*",end=" ")
			j+=1
		else:
			print(" ",end=" ")
			j+=1
		r+=1
	print()





