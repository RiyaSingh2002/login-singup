import json
user=input("login/signup")
dic={}
dic1={}
a=[]
if user=="signup":
    name=input("enter your name")
    age=int(input("enter your age"))
    gender=input("m/f")
    mail=input("enter mail")
    ph=int(input("enter 10_digit phone number"))
    password=input("enter any strong password")
    dic["Name"]=name
    dic["Age"]=age
    dic["Gender"]=gender
    dic["Mail"]=mail
    dic["mobile"]=ph
    dic["Password"]=password
    # print(dic)
    with open("riya.json","a+") as file:
        json.dump(dic,file,indent=4)  
        a.append(dic)
        dic1["users"]=a
    a,b,c,d=0,0,0,0
    i=0
    l1=["!","@","#","$","%","^","&","*","~"]    
    while i<len(password):
        if password[i]>="A" and password[i]<="Z":
            a+=1
        elif password[i]>="a" and password[i]<="z":
            b+=1
        elif password[i] in l1:
            c+=1
        elif int(password[i])>=0 and int(password[i])<=9:
            d+=1
        i+=1
    if a>=1 and b>=1 and c>=1 and d>=1 and len(password)>=8 and len(password)<=20:
        print("yes")
    else:
        print("please enter a strong password")
    confirm_p=input("again enter same password")
    if password==confirm_p:
        print("successfully resistered")
print(dic1)        