import string
def is_word_guessed(secret_word, letters_guessed):
    return "you lose"
def get_guessed_word(secret_word, letters_guessed):
    index = 0
    guessed_word = ""
    # letters_guessed=["h","a","n","g","m","a","n"]
    while (index < len(secret_word)):
        if secret_word[index] in letters_guessed:
            guessed_word += secret_word[index]
        else:
            guessed_word += "_"
        index += 1   
    return guessed_word
def get_available_letters(letters_guessed):
    import string
    letters_left = string.ascii_lowercase
    return letters_left
def hangman(secret_word):
    print ("Welcome to the game, Hangman!")
    print ("I am thinking of a word that is " + str(len(secret_word)) + " letters long.")
    print ("")
    # while True:
    letters_guessed = []   
    available_letters = get_available_letters(letters_guessed)
    print ("Available letters: " + available_letters)
    i=1
    while i<len(secret_word):
        guess =input("Please guess a letter: ")
        letter = guess.lower()
        if letter in secret_word:
            letters_guessed.append(letter)
            print ("Good guess: " + get_guessed_word(secret_word, letters_guessed))
            print ("")
        # elif is_word_guessed(secret_word, letters_guessed) == True:
            # print (" * * Congratulations, you won! * * ")
            # print ("you wants to play again")
        else:
            print ("Oops! That letter is not in my word: " + get_guessed_word(secret_word, letters_guessed))
            letters_guessed.append(letter)
            print ("")
        i=i+1    
secret_word="hangman"        
# secret_word = choose_word()
hangman(secret_word)
get_word=0
word_list=0
play=0
def display_hangman(tries):
    stages = [  """
                   --------
                   |      |
                   |      O
                   |     \\|/
                   |      |
                   |     / \\
                   -
                   """,
                   """
                   --------
                   |      |
                   |      O
                   |     \\|/
                   |      |
                   |     /
                   -
                   """,
                   """
                   --------
                   |      |
                   |      O
                   |     \\|/
                   |      |
                   |
                   -
                   """,
                   """
                   --------
                   |      |
                   |      O
                   |     \\|
                   |      |
                   |
                   -
                   """,
                   """
                   --------
                   |      |
                   |      O
                   |      |
                   |      |
                   |
                   -
                   """,
                   """
                   --------
                   |      |
                   |      O
                   |
                   |
                   |
                   -riya
                   """,
                   """
                   --------
                   |      |
                   |      
                   |
                   |
                   |
                   -
                   """
    ]
    return stages[tries]

def main():
    word = get_word(word_list)
    play(word)
    while input("Again? (Y/N) ").upper() == "Y":
        word = get_word(word_list)
        play(word)

if __name__ == "__main__":
    main()