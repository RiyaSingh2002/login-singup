# def my(x):
# 	count1=0
# 	count2=0
# 	y=x.split( )
# 	i=0
# 	if x[i]>"A" and x[i]<"z":
# 		count1=count1+x[i]
# 	elif x[i]>"a" and x[i]<"z":
# 		count2=count2+x[i]
# 	i=i+1
# print("upper case")
# print("lower case")
# x="My Name Is Puja RANI"

# my(x)