# a=input()
# b=input()
# c=input()
# if a>b and a<c:
#     print(a,"sec max")
# elif b>a and b<c:
#     print(b,"sec max")
# elif c<b and c<a:
#     # print(c,"second max")    
a=str(input("enter any number"))
x=list(a)
if (x[-2])==7:
    print("yes")
elif (x[-2])!=7:
    print("no")

