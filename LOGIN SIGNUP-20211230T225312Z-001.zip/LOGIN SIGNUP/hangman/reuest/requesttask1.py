import json
import requests
from requests.api import options, request
res=requests.get("http://saral.navgurukul.org/api/courses")
data=res.json()
# print(data)
def opt(select,var2,slug,data2):
    while True:
        x=var2
        options=input("enter your option up next exit back")
        if options=="up":
            print(x)
            x=x-1
            req=requests.get("http://saral.navgurukul.org/api/courses"+str(select))
            r=req.json()
            print("content",r["content"])
            print(x)
        elif options=="next":
            x=x+1
            req=requests.get("http://saral.navgurukul.org/api/courses"+str(select))
            r1=req.json()
            print("content",r1["content"])
            print(x)
        elif options=="back":
            c=1
            for dic1 in data2["data"]:
                print(c,dic1["name"])
                c=c+1
                for i in dic1["childexercises"]:
                    print("    ",c,i["name"])
                    c=c+1
        else:
            break
        def course():
            index=0
            for i in data["availabecourse"]:
                print(index+1,i["name"],i["id"])
                index=index+1
            count=0
            for courses in data["availablecourses"]:
                course=int(input("selectyour courses"))
                slect=data["availabecourse"][course-1]["id"]
                var=requests.get("http://saral.navgurukul.org/api/courses"+str(select)+"/exercise/get")
                data2=var.json()
                slug=[]
                count3=1

                for dic_data2 in data2["data"]:
                    print(count3,dic_data2["name"])
                    slug.append(dic_data2["slug"])
                    count3=count3+1
                    for child in dic_data2["childexercises"]:
                        print("    ",count3,child["name"])
                        slug.append(child["slug"])
                        count3+=1
                var2=int(input("show content slug"))
                var3=requests.get("http://saral.navgurukul.org/api/courses"+str(select)+"/exercise/get")
                data3=var3.json()
                print(data3["content"])
                opt(slect,var,slug,data2)
    course()
def func1():
    index=0
    for i in data["availableCourses"]:
        print(index+1,i["name"],i["id"])
        index+=1
func1()
