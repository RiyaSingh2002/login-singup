import json
import requests
from requests.api import options, request
res=requests.get("http://saral.navgurukul.org/api/courses")
data=res.json()
def func1():
    index=0
    for i in data["availableCourses"]:
        print(index+1,i["name"],i["id"])
        index+=1z
func1()
