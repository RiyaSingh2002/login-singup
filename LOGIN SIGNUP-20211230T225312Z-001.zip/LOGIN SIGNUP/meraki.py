a="riya"
print(type)